import{l as o,a as r}from"../chunks/C4X_VlR2.js";export{o as load_css,r as start};
